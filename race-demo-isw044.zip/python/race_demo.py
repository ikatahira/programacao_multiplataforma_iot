import threading
import time

N = 100
contador_inseguro = 0
contador_seguro = 0
lock = threading.Lock()


def incrementar_inseguro():
    global contador_inseguro
    temp = contador_inseguro
    time.sleep(0.0001)
    contador_inseguro = temp + 1


def incrementar_seguro():
    global contador_seguro
    with lock:
        temp = contador_seguro
        time.sleep(0.0001)
        contador_seguro = temp + 1


def rodar(funcao, n):
    threads = [threading.Thread(target=funcao) for _ in range(n)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()


if __name__ == "__main__":
    rodar(incrementar_inseguro, N)
    rodar(incrementar_seguro, N)

    print(f"Esperado: {N}")
    print(f"SEM protecao -> contador final = {contador_inseguro}")
    print(f"COM lock -> contador final = {contador_seguro}")
