const N = 100;
let contadorInseguro = 0;
let contadorSeguro = 0;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function incrementarInseguro() {
  const temp = contadorInseguro;
  await sleep(1);
  contadorInseguro = temp + 1;
}

class Mutex {
  constructor() {
    this._p = Promise.resolve();
  }
  lock() {
    let resolveLock;
    const lockPromise = new Promise((res) => (resolveLock = res));
    const willLock = this._p.then(() => resolveLock);
    this._p = this._p.then(() => lockPromise);
    return willLock;
  }
}
const mutex = new Mutex();

async function incrementarSeguro() {
  const unlock = await mutex.lock();
  const temp = contadorSeguro;
  await sleep(1);
  contadorSeguro = temp + 1;
  unlock();
}

async function main() {
  await Promise.all(Array.from({ length: N }, incrementarInseguro));
  await Promise.all(Array.from({ length: N }, incrementarSeguro));

  console.log(`Esperado: ${N}`);
  console.log(`SEM protecao -> contador final = ${contadorInseguro}`);
  console.log(`COM lock (mutex) -> contador final = ${contadorSeguro}`);
}

main();
