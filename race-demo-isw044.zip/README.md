# ISW044 — Condição de corrida na prática (Java, Python, JavaScript)

Este repositório roda o **mesmo bug de concorrência** em três linguagens diferentes,
igual ao exemplo da Missão "Sistemas Distribuídos". Cada exemplo incrementa um
contador compartilhado 100 vezes, uma vez **sem proteção** e uma vez **com lock/mutex**.

## Como rodar no GitHub Codespaces

1. Suba esta pasta para um repositório novo no GitHub.
2. No repositório, clique em **Code → Codespaces → Create codespace on main**.
3. Espere o ambiente instalar Java, Python e Node (uns 30-60s na primeira vez).
4. No terminal do Codespace, rode cada exemplo:

```bash
# Java
cd java && javac RaceDemo.java && java RaceDemo

# Python
cd python && python3 race_demo.py

# JavaScript
cd javascript && node race_demo.js
```

5. **Rode cada um várias vezes seguidas.** O valor "SEM proteção" muda a cada
   execução (ou fica sempre errado, no caso do JS) — o valor "COM lock" é
   *sempre* 100.

## Resultado real (capturado ao rodar este exato código)

```
=== JAVA ===
Esperado: 100
SEM protecao -> contador final = 30
COM synchronized -> contador final = 100

(rodando de novo: 28, depois 27 — muda a cada execução)

=== PYTHON ===
Esperado: 100
SEM protecao -> contador final = 20
COM lock -> contador final = 100

(rodando de novo: 21, depois 20)

=== JAVASCRIPT (Node) ===
Esperado: 100
SEM protecao -> contador final = 1
COM lock (mutex) -> contador final = 100

(em JS o resultado sem proteção é sempre 1 — todas as 100 chamadas leem o
contador em 0 antes de qualquer uma escrever de volta)
```

## Por que isso acontece

Em todas as linguagens, a versão "sem proteção" faz:
1. Lê o valor atual do contador
2. Espera um pouco (simulando processamento)
3. Escreve valor + 1 de volta

Se duas execuções fazem o passo 1 antes de qualquer uma fazer o passo 3, uma
das escritas **sobrescreve** a outra — um incremento é perdido. Isso é a
**condição de corrida** estudada na Missão de Sistemas Distribuídos.

A versão "com lock" (`synchronized` em Java, `threading.Lock()` em Python,
a classe `Mutex` em JavaScript) garante que só uma execução por vez passe
pelos 3 passos — por isso o resultado é sempre correto.

## GitHub Actions — prova pública automática

Este repositório já vem com `.github/workflows/race-demo.yml`. Assim que você
subir o código para o GitHub, ele roda os 3 exemplos automaticamente a cada
push e salva o resultado em dois lugares:

1. No **resumo da execução** (aba *Actions* → clique na execução → o
   resultado aparece formatado na tela, sem precisar baixar nada).
2. Como **artefato para download** (`resultado-condicao-de-corrida.md`),
   caso queira guardar ou compartilhar o arquivo.

Pra rodar manualmente sem precisar dar push: aba *Actions* → selecione o
workflow "Rodar exemplos de condicao de corrida" → **Run workflow**.

Isso é útil pra mostrar pra turma um resultado "oficial", gerado pelo próprio
GitHub, sem depender de ninguém ter Codespaces aberto no momento da aula.



- **GitHub Codespaces** (este repositório) — cada aluno abre seu próprio
  ambiente no navegador, sem instalar nada. Melhor opção para turma inteira.
- **Replit** (replit.com) — cole o código Python ou JS, roda direto no
  navegador, sem sequer precisar de conta GitHub. Mais rápido de configurar,
  mas não roda Java tão bem de graça.
- **GitHub Actions** — um workflow que roda os 3 scripts automaticamente a
  cada push e salva a saída como log público, para "provar" o resultado sem
  ninguém precisar rodar nada manualmente.
- **Terminal local** — se a sala tiver Java/Python/Node instalados, roda
  igualzinho, só trocar o Codespace pelo terminal do próprio PC.
