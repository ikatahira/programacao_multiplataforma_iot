import java.util.concurrent.atomic.AtomicInteger;

public class RaceDemo {
    static int contadorInseguro = 0;
    static int contadorSeguro = 0;
    static final Object lock = new Object();

    static void incrementarInseguro() {
        int temp = contadorInseguro;
        try { Thread.sleep(0, 100000); } catch (InterruptedException e) {}
        contadorInseguro = temp + 1;
    }

    static void incrementarSeguro() {
        synchronized (lock) {
            int temp = contadorSeguro;
            try { Thread.sleep(0, 100000); } catch (InterruptedException e) {}
            contadorSeguro = temp + 1;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        int n = 100;

        Thread[] inseguras = new Thread[n];
        for (int i = 0; i < n; i++) {
            inseguras[i] = new Thread(RaceDemo::incrementarInseguro);
        }
        for (Thread t : inseguras) t.start();
        for (Thread t : inseguras) t.join();

        Thread[] seguras = new Thread[n];
        for (int i = 0; i < n; i++) {
            seguras[i] = new Thread(RaceDemo::incrementarSeguro);
        }
        for (Thread t : seguras) t.start();
        for (Thread t : seguras) t.join();

        System.out.println("Esperado: " + n);
        System.out.println("SEM protecao -> contador final = " + contadorInseguro);
        System.out.println("COM synchronized -> contador final = " + contadorSeguro);
    }
}
